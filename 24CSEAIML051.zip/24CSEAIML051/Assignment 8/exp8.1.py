def square(num):
    return num * num
number = 5
print("Square:", square(number))
