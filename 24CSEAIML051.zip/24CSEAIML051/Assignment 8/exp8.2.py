def check_even_odd(num):
    if num % 2 == 0:
        return "Even"
    else:
        return "Odd"
number = 7
print("The number is:", check_even_odd(number))
