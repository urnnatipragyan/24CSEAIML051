ch = input("Enter an alphabet: ")
if ch.lower() in ['a', 'e', 'i', 'o', 'u']:
    print("It is a Vowel")
else:
    print("It is a Consonant") 
