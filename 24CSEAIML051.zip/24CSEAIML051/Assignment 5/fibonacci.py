a = 0
b = 1
sum = 0 
print("fibonacci")