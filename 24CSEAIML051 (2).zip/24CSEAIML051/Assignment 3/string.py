str1 = input("Enter first string: ")
str2 = input("Enter second string: ")
if str1 == str2:
    print("Both strings are equal")
else:
    print("Strings are not equal")
