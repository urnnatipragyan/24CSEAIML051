for i in [1, 2, 3]:
    print(i)


for i in (4, 5, 6):
    print(i)


for key in {"a": 1, "b": 2}:
    print(key)


for i in {7, 8, 9}:
    print(i)
