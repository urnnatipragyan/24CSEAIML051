i = 2
while i <= 100:
    print("1/", i, "=", 1/i)
    i += 1
