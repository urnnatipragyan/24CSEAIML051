def student(name,course):
    print("name:",name)
    print("course:",course)
student(course="python",name="anu")