l = [1,2,3,4,5]
l1=list(map(lambda n:n*n,l))
print(l1)
