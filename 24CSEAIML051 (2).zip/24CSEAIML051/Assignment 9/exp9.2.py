def product(a,b):
    print("product:",a*b)
product(9,6)