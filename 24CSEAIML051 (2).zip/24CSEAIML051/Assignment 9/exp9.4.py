def greet(name="student"):
    print("hello",name)
greet()                                          