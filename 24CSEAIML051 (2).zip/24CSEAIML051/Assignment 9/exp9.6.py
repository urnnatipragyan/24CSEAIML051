def bill(amount=100):
    print("bill amount:",amount)
bill(500)
bill()