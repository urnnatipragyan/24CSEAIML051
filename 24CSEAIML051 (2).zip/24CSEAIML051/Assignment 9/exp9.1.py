def add(a,b):
    print("Add:",a+b)
add(5,10)
