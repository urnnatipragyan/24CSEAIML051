def simple_interest(p,r,t):
    return(p*r*t)/100
p=float(input("enter principle amount:"))
r=float(input("enter rate of interest:"))
t=float(input("enter time(in year):"))
print("simple interest=",simple_interest(p,r,t))