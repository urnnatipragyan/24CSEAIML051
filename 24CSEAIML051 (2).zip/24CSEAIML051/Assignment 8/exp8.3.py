def add_numbers(a, b):
    return a + b
num1 = 10
num2 = 20
print("Sum:", add_numbers(num1, num2))
