def reverse_string(s):
    return s[::-1]
text=input("enter a string:")
print("Reversed string:",reverse_string(text))